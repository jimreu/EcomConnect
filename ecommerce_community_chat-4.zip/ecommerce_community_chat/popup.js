const chatTab = document.getElementById("chat-tab");
const profileTab = document.getElementById("profile-tab");
const chatContent = document.getElementById("chat-content");
const profileContent = document.getElementById("profile-content");
const sendMessageBtn = document.getElementById("send-message-btn");
const messageInput = document.getElementById("message-input");
const messagesContainer = document.getElementById("messages-container");
const profileForm = document.getElementById("profile-form");
const nameInput = document.getElementById("name-input");
const companyInput = document.getElementById("company-input");
const profilePhotoInput = document.getElementById("profile-photo-input");
const linkedinInput = document.getElementById("linkedin-input");
const emailInput = document.getElementById("email-input");
const moreInfoTab = document.getElementById("more-info-tab");
const moreInfoContent = document.getElementById("more-info-content");
const userList = document.querySelectorAll(".user-list")[0];


moreInfoTab.addEventListener("click", () => {
  chatContent.classList.add("hidden");
  profileContent.classList.add("hidden");
  moreInfoContent.classList.remove("hidden");
  chatTab.classList.remove("active");
  profileTab.classList.remove("active");
  moreInfoTab.classList.add("active");
});

linkedinInput.addEventListener('blur', (event) => {
  event.preventDefault();
  userData.linkedin = linkedinInput.value.trim();
});

// Display the email associated with the Google account
function getEmailFromGoogleAccount() {
  chrome.identity.getProfileUserInfo((userInfo) => {
    if (userInfo && userInfo.email) {
      emailInput.value = userInfo.email;
    } else {
      console.error("Error getting user email from Google account.");
    }
  });
}

document.getElementById('connect-tab').addEventListener('click', function () {
  switchTab('connect-content');
});

document.getElementById('connect-tab').addEventListener('click', () => {
  switchTab('connect');
});

document.addEventListener("DOMContentLoaded", () => {
  loadUserData(() => {
    loadMessages();
  });
  getEmailFromGoogleAccount(); // Add this line
});

nameInput.addEventListener('blur', (event) => {
  event.preventDefault();
  userData.name = nameInput.value.trim();
});

companyInput.addEventListener('blur', (event) => {
  event.preventDefault();
  userData.company = companyInput.value.trim();
});

profilePhotoInput.addEventListener('change', (event) => {
  event.preventDefault();
  if (profilePhotoInput.files && profilePhotoInput.files[0]) {
    resizeImage(profilePhotoInput.files[0], 200, 200, (resizedImage) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        const profilePhotoPreview = document.getElementById("profile-photo-preview");
        profilePhotoPreview.src = e.target.result;
        profilePhotoPreview.style.display = "block";
        
        // Merge the updated profile photo with the existing userData
        userData = {
          ...userData,
          profilePhoto: e.target.result
        };

        // Save the profile after updating the profile photo
        saveProfile();
      };
      reader.readAsDataURL(resizedImage);
    });
  }
});

profileForm.addEventListener("submit", (event) => {
  event.preventDefault();
  saveProfile();
});


let userData = {
  name: "",
  company: "",
  profilePhoto: chrome.runtime.getURL("defaultprofileicon.png"),
};
let lastMessageIsUser = false;

chatTab.addEventListener("click", () => {
  chatContent.classList.remove("hidden");
  profileContent.classList.add("hidden");
  moreInfoContent.classList.add("hidden"); 
  chatTab.classList.add("active");
  profileTab.classList.remove("active");
  moreInfoTab.classList.remove("active"); 
});

profileTab.addEventListener("click", () => {
  chatContent.classList.add("hidden");
  profileContent.classList.remove("hidden");
  moreInfoContent.classList.add("hidden"); 
  chatTab.classList.remove("active");
  profileTab.classList.add("active");
  moreInfoTab.classList.remove("active");
});

document.addEventListener("DOMContentLoaded", () => {
  chatTab.classList.add("active");
});

function loadUserData(callback) {
  chrome.storage.sync.get(["name", "company", "linkedin"], (result) => { // Add linkedin here
    userData = {
      name: result.name || "",
      company: result.company || "",
      linkedin: result.linkedin || "" 
    };

    nameInput.value = userData.name;
    companyInput.value = userData.company;
    linkedinInput.value = userData.linkedin; 

    chrome.storage.local.get(["profilePhoto"], (result) => {
      let profilePhotoURL;
      if (result.profilePhoto) {
        profilePhotoURL = result.profilePhoto;
      } else {
        profilePhotoURL = chrome.runtime.getURL("defaultprofileicon.png");
      }
      userData.profilePhoto = profilePhotoURL;
      updateProfilePhotoPreview();

      if (callback) {
        callback();
      }
    });
  });
}




function removeExpiredMessages(messages) {
  const currentTime = Date.now();
  const expirationTime = 48 * 60 * 60 * 1000; // 48 hours in milliseconds
  return messages.filter((msg) => currentTime - parseInt(msg.id.split('-')[1]) < expirationTime);
}

function loadMessages() {
  while (messagesContainer.firstChild) {
    messagesContainer.removeChild(messagesContainer.firstChild);
  }

  chrome.storage.local.get(["messages"], (result) => {
    let messages = result.messages || [];
    messages = removeExpiredMessages(messages); // Remove expired messages
    let lastMessage = null;
    messages.forEach((msg, index) => {
      if (msg.isImage) {
        createMessage(null, msg.isUser, msg.id, userData.name, userData.company, userData.profilePhoto, msg.imageSrc);
      } else {
        createMessage(msg.text, msg.isUser, msg.id, userData.name, userData.company, userData.profilePhoto);
      }
      lastMessage = {
        isUser: msg.isUser,
        id: msg.id,
      };
    });
    // Save the messages back to storage after removing expired ones
    chrome.storage.local.set({ messages });
  });
}


function createMessage(message, isUser = false, messageId = null, userName, userCompany, userProfilePhoto, imageSrc = null) {
  const messageDiv = document.createElement("div");
  messageDiv.id = messageId || `message-${Date.now()}`;
  messageDiv.classList.add("message");

  if (isUser) {
    messageDiv.classList.add("user");
    messageDiv.addEventListener("dblclick", () => removeMessage(messageDiv));
  }

  if (!isUser || !lastMessageIsUser) {
    const profileInfoDiv = document.createElement("div");
    profileInfoDiv.classList.add("profile-info");

    const profileImg = document.createElement("img");
    profileImg.src = userProfilePhoto;
    profileImg.alt = userName;
    profileImg.classList.add("profile-image"); // Add this line

    const nameDiv = document.createElement("div");
    nameDiv.textContent = userName;
    nameDiv.classList.add("profile-name"); // Add this line

    const fromText = document.createElement("span");
    fromText.textContent = "\u00A0from\u00A0"; // Add non-breaking spaces before and after 'from'
    fromText.style.color = "grey";

    const companyDiv = document.createElement("div");
    companyDiv.textContent = userCompany;
    companyDiv.style.display = "inline";
    companyDiv.classList.add("profile-company"); // Add this line

    // Add verified tick
    const verifiedTick = document.createElement("img");
    verifiedTick.src = "verifiedicon.png"; // Set the source to the image file
    verifiedTick.alt = "Verified";
    verifiedTick.style.marginLeft = "4px"; // Add a small margin on the left
    verifiedTick.style.height = "14px"; // Adjust the tick size
    verifiedTick.style.width = "14px"; // Adjust the tick size

    profileInfoDiv.appendChild(profileImg);
    profileInfoDiv.appendChild(nameDiv);
    profileInfoDiv.appendChild(fromText); // Add 'from' text
    profileInfoDiv.appendChild(companyDiv);
    profileInfoDiv.appendChild(verifiedTick); // Add the verified tick
    messageDiv.appendChild(profileInfoDiv);
  }

  const messageContentDiv = document.createElement("div");
  messageContentDiv.classList.add("message-content");

  if (imageSrc) {
    const messageImg = document.createElement("img");
    messageImg.src = imageSrc;
    messageImg.classList.add("attached-image");
    messageContentDiv.appendChild(messageImg);
  } else {
    messageContentDiv.textContent = message;
  }

  messageDiv.appendChild(messageContentDiv);

  messagesContainer.appendChild(messageDiv);
  messagesContainer.scrollTop = messagesContainer.scrollHeight;

  lastMessageIsUser = isUser;
}




function removeMessage(element) {
  messagesContainer.removeChild(element);
  chrome.storage.local.get(["messages"], (result) => { 
    const messages = result.messages || [];
    const messageIndex = messages.findIndex((msg) => msg.id === element.id);

    if (messageIndex !== -1) {
      messages.splice(messageIndex, 1);
      chrome.storage.local.set({ messages }); 
    }
  });
}

function saveMessage(message, isUser, isImage = false, imageSrc = null) {
  chrome.storage.local.get(["messages"], (result) => { // Change this line
    const messages = result.messages || [];
    const messageId = `message-${Date.now()}`;

    if (isImage) {
      messages.push({
        isImage: true,
        imageSrc: imageSrc,
        isUser: isUser,
        id: messageId,
      });
    } else {
      messages.push({
        text: message,
        isUser: isUser,
        id: messageId,
      });
    }

    chrome.storage.local.set({ messages }); // Change this line
  });
}

sendMessageBtn.addEventListener("click", () => {
  const message = messageInput.value.trim();
  if (message) {
    createMessage(message, true, null, userData.name, userData.company, userData.profilePhoto);
    messageInput.value = "";
    saveMessage(message, true);
  }
});

messageInput.addEventListener("keydown", (event) => {
  if (event.key === "Enter") {
    const message = messageInput.value.trim();
    if (message) {
      createMessage(message, true, null, userData.name, userData.company, userData.profilePhoto);
      messageInput.value = "";
      saveMessage(message, true);
    }
  }
});

function saveProfile() {
  const nameInput = document.getElementById("name-input");
  const companyInput = document.getElementById("company-input");
  const profileImageInput = document.getElementById("profile-photo-input");

  if (profileImageInput.files[0]) {
    const reader = new FileReader();
    reader.onload = function (e) {
      const profileImage = e.target.result;
      document.getElementById("profile-photo-preview").src = profileImage;
      localStorage.setItem("profileImage", profileImage);
    };
    reader.readAsDataURL(profileImageInput.files[0]);
  }

  localStorage.setItem("name", nameInput.value);
  localStorage.setItem("company", companyInput.value);
}




function updateProfilePhotoPreview() {
  const profilePhotoPreview = document.getElementById("profile-photo-preview");
  if (userData.profilePhoto) {
    profilePhotoPreview.src = userData.profilePhoto;
    profilePhotoPreview.style.display = "block";
  } else {
    profilePhotoPreview.style.display = "none";
  }
}

profilePhotoInput.addEventListener('change', (event) => {
  event.preventDefault();
  if (profilePhotoInput.files && profilePhotoInput.files[0]) {
    resizeImage(profilePhotoInput.files[0], 200, 200, (resizedImage) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        const profilePhotoPreview = document.getElementById("profile-photo-preview");
        profilePhotoPreview.src = e.target.result;
        profilePhotoPreview.style.display = "block";
        userData.profilePhoto = e.target.result;
      };
      reader.readAsDataURL(resizedImage);
    });
  }
});

function resizeImage(file, maxWidth, maxHeight, callback) {
  const img = new Image();
  img.src = URL.createObjectURL(file);

  img.onload = () => {
    const canvas = document.createElement("canvas");
    let width = img.width;
    let height = img.height;

    if (width > height) {
      if (width > maxWidth) {
        height *= maxWidth / width;
        width = maxWidth;
      }
    } else {
      if (height > maxHeight) {
        width *= maxHeight / height;
        height = maxHeight;
      }
    }

    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext("2d");
    ctx.drawImage(img, 0, 0, width, height);

    canvas.toBlob((blob) => {
      callback(blob);
    }, file.type);
  };
}


const attachImageBtn = document.getElementById("attach-image-btn");
const attachImageInput = document.getElementById("attach-image-input");

attachImageBtn.addEventListener("click", () => {
  attachImageInput.click(); // Trigger the attach image input file selector when the "attach image" button is clicked
});

attachImageInput.addEventListener("change", (event) => {
  event.preventDefault();
  if (attachImageInput.files && attachImageInput.files[0]) {
    const reader = new FileReader();

    reader.onload = (e) => {
      const imageSrc = e.target.result;
      const messageId = `message-${Date.now()}`;
      createMessage(null, true, messageId, userData.name, userData.company, userData.profilePhoto, imageSrc);

      // Save the image to the storage
      saveMessage(null, true, true, imageSrc); // Change this line
    };

    reader.readAsDataURL(attachImageInput.files[0]);
  }
});




function switchTab(tabId) {
  const targetTabId = tabId + "-content";

  const tabContents = document.querySelectorAll(".tab-content");
  const tabs = document.querySelectorAll(".tab");

  // Hide all tab content
  for (let tabContent of tabContents) {
    tabContent.classList.add("hidden");
  }

  // Remove active style from all tabs
  for (let tab of tabs) {
    tab.classList.remove("active");
  }

  // Show the content of the target tab
  document.getElementById(targetTabId).classList.remove("hidden");

  // Add active style to the clicked tab
  document.getElementById(tabId + "-tab").classList.add("active");

  // Load the connect tab content
  if (tabId === "connect") {
    loadConnectTab();
  }
}


function loadProfileData() {
  chrome.storage.sync.get(["name", "company", "linkedin"], (data) => {
    document.getElementById("name").value = data.name || "";
    document.getElementById("company").value = data.company || "";
    document.getElementById("linkedin").value = data.linkedin || "";

    // Call handleInputChange after loading profile data
    handleInputChange();
  });
}

function handleInputChange() {
  const nameInput = document.querySelector("#name-input");
  const companyInput = document.querySelector("#company-input");
  const linkedinInput = document.querySelector("#linkedin-input");
  const displayInConnectCheckbox = document.getElementById("display-in-connect");

  if (nameInput.value && companyInput.value && linkedinInput.value) {
    displayInConnectCheckbox.disabled = false;
  } else {
    displayInConnectCheckbox.checked = false;
    displayInConnectCheckbox.disabled = true;
  }
}

function handleCheckboxChange(event) {
  const isChecked = event.target.checked;
  chrome.storage.sync.set({ displayInConnect: isChecked });
}

function loadCheckboxState() {
  chrome.storage.sync.get("displayInConnect", (data) => {
    const displayInConnectCheckbox = document.getElementById("display-in-connect");
    displayInConnectCheckbox.checked = data.displayInConnect || false;
  });
}

function loadConnectTab() {
  chrome.storage.sync.get(["name", "company", "linkedin", "displayInConnect"], (userData) => {
    // Check if the user's profile should be displayed
    if (!userData.displayInConnect) return;

    console.log("Sync storage data:", userData); // Debugging line

    chrome.storage.local.get(["profilePhoto"], (localData) => {
      console.log("Local storage data:", localData); // Debugging line

      const userList = document.querySelector(".user-list");
      userList.innerHTML = ""; // Clear the user list

      // Add user details
      const listItem = document.createElement("li");
      listItem.className = "user-list-item";

      const img = document.createElement("img");
      img.src = localData.profilePhoto || "default-profile.png";
      img.alt = `${userData.name}'s Profile Photo`;

      const userInfo = document.createTextNode(`${userData.name} from ${userData.company}`);
      const linkedinButton = document.createElement("button");
      linkedinButton.textContent = "LinkedIn";
      linkedinButton.addEventListener("click", () => {
        window.open(userData.linkedin, "_blank");
      });

      listItem.appendChild(img);
      listItem.appendChild(userInfo);
      listItem.appendChild(linkedinButton);

      userList.appendChild(listItem);
    });
  });
}



document.addEventListener("DOMContentLoaded", function () {
  // Set the initial active tab
  document.getElementById("chat-tab").click();

  document.getElementById("chat-tab").addEventListener("click", () => {
    switchTab("chat");
  });

  document.getElementById("connect-tab").addEventListener("click", () => {
    switchTab("connect");
  });

  document.getElementById("profile-tab").addEventListener("click", () => {
    switchTab("profile");
  });

  document.getElementById("more-info-tab").addEventListener("click", () => {
    switchTab("more-info");
  });
   // Add the event listener for the 'name', 'company', and 'linkedin' input fields
  const inputs = document.querySelectorAll("#profile-content input[type='text']");
  inputs.forEach((input) => {
    input.addEventListener("input", handleInputChange);
  });

  // Add the event listener for the checkbox
  const displayInConnectCheckbox = document.getElementById("display-in-connect");
  displayInConnectCheckbox.addEventListener("change", handleCheckboxChange);

  // Load the initial state of the checkbox
  loadCheckboxState();

  // Load profile data
  loadProfileData();
});

document.getElementById("news-feed-tab").addEventListener("click", () => {
  switchTab("news-feed");
});

function displayPost(badge, message, profileImageSrc, profileName, profileCompany, time, imageFile) {
  if (imageFile) {
    const reader = new FileReader();
    reader.onload = function (event) {
      const imageSrc = event.target.result;
      const postData = {
        profileImage: profileImageSrc,
        name: profileName,
        company: profileCompany,
        content: message,
        badge: badge,
        imageSrc: imageSrc
      };

      const postElement = createPost(postData);
      document.getElementById("feed-container").prepend(postElement);
    };
    reader.readAsDataURL(imageFile);
  } else {
    const postData = {
      profileImage: profileImageSrc,
      name: profileName,
      company: profileCompany,
      content: message,
      badge: badge
    };

    const postElement = createPost(postData);
    document.getElementById("feed-container").prepend(postElement);
  }
}


document.getElementById("attach-post-image-btn").addEventListener("click", () => {
  document.getElementById("attach-post-image-input").click();
});

function createProfileInfoElement(profileImageSrc, profileName, profileCompany) {
  const profileInfoDiv = document.createElement("div");
  profileInfoDiv.classList.add("profile-info");

  const profileImg = document.createElement("img");
  profileImg.src = profileImageSrc;
  profileImg.alt = profileName;

  const nameDiv = document.createElement("div");
  nameDiv.textContent = profileName;

  const fromText = document.createElement("span");
  fromText.textContent = "\u00A0from\u00A0"; // Add non-breaking spaces before and after 'from'

  const companyDiv = document.createElement("div");
  companyDiv.textContent = profileCompany;
  companyDiv.style.display = "inline";

  profileInfoDiv.appendChild(profileImg);
  profileInfoDiv.appendChild(nameDiv);
  profileInfoDiv.appendChild(fromText);
  profileInfoDiv.appendChild(companyDiv);

  return profileInfoDiv;
}

function submitPost(event, userProfileImage, userName, userCompany) {
  event.preventDefault();

  const badge = document.getElementById("badge-select").value;
  const message = document.getElementById("post-input").value;
  const imageFile = document.getElementById("attach-post-image-input").files[0];

  // Get the user information from local storage
  const profileImageSrc = localStorage.getItem("profileImage") || userProfileImage;
  const profileName = localStorage.getItem("name") || userName;
  const profileCompany = localStorage.getItem("company") || userCompany;
  const time = new Date().toLocaleString();

  if (message) {
    displayPost(badge, message, profileImageSrc, profileName, profileCompany, time, imageFile);
    clearPostInputFields();
  }
}

document.getElementById("profile-form").addEventListener("submit", submitPost);


document.getElementById("attach-post-image-btn").addEventListener("click", function () {
  document.getElementById("attach-post-image-input").click();
});


function timeAgo(date) {
  const seconds = Math.floor((new Date() - date) / 1000);
  const intervals = [
    { label: 'year', seconds: 31536000 },
    { label: 'month', seconds: 2592000 },
    { label: 'week', seconds: 604800 },
    { label: 'day', seconds: 86400 },
    { label: 'hour', seconds: 3600 },
    { label: 'minute', seconds: 60 },
  ];

  for (const interval of intervals) {
    const count = Math.floor(seconds / interval.seconds);
    if (count >= 1) {
      return `${count} ${interval.label}${count > 1 ? 's' : ''} ago`;
    }
  }

  return 'just now';
}

function createPost(postData) {
  const post = document.createElement('div');
  post.classList.add('post');

  const postBadge = document.createElement('span');
  postBadge.classList.add('post-badge');
  postBadge.textContent = postData.badge;
  post.appendChild(postBadge);

  const postContentElement = document.createElement('div');
  postContentElement.className = 'post-content';

  const postText = document.createElement('p');
  postText.innerText = postData.content;

  postContentElement.appendChild(postText);

  if (postData.imageSrc) {
    const postImage = document.createElement('img');
    postImage.className = 'post-image';
    postImage.src = postData.imageSrc;

    postContentElement.appendChild(postImage);
  }

  const postHeader = document.createElement('div');
  postHeader.classList.add('post-header');

  const postProfileImage = document.createElement('img');
  postProfileImage.classList.add('post-profile-image');
  postProfileImage.src = postData.profileImage;
  postProfileImage.alt = 'Profile Image';

  const postInfo = document.createElement('div');
  postInfo.classList.add('post-info');

  const postName = document.createElement('span');
  postName.classList.add('post-name');
  postName.textContent = postData.name;

  const postCompany = document.createElement('span');
  postCompany.classList.add('post-company');
  postCompany.textContent = ` from ${postData.company}`;

  postInfo.appendChild(postName);
  postInfo.appendChild(postCompany);
  postHeader.appendChild(postProfileImage);
  postHeader.appendChild(postInfo);

  post.appendChild(postHeader);
  post.appendChild(postContentElement);

  // Add the timestamp
  const postTimestamp = document.createElement('span');
  postTimestamp.classList.add('post-timestamp');
  postTimestamp.textContent = timeAgo(postData.timestamp);
  post.appendChild(postTimestamp);

  return post;
}


function sendPost() {
  const postInput = document.getElementById('post-input');
  const badgeSelect = document.getElementById('badge-select');
  const attachPostImageInput = document.getElementById('attach-post-image-input');

  // Read values from inputs directly
  const nameInput = document.getElementById('name-input');
  const companyInput = document.getElementById('company-input');
  const profileImageInput = document.getElementById('profile-photo-preview');

  if (postInput.value.trim() === '') {
    return;
  }

  const post = {
    name: nameInput.value || 'Anonymous',
    company: companyInput.value || 'Unknown Company',
    profileImage: profileImageInput.src || 'default-profile-image.png',
    content: postInput.value,
    badge: badgeSelect.value,
  };

  if (attachPostImageInput.files[0]) {
    const reader = new FileReader();
    reader.onload = function (e) {
      post.image = e.target.result;
      const newPost = createPost(post);
      const feedContainer = document.getElementById('feed-container');
      feedContainer.prepend(newPost);
      postInput.value = '';
      attachPostImageInput.value = '';
    };
    reader.readAsDataURL(attachPostImageInput.files[0]);
  } else {
    const newPost = createPost(post);
    const feedContainer = document.getElementById('feed-container');
    feedContainer.prepend(newPost);
    postInput.value = '';
  }
}

document.getElementById("profile-form").addEventListener("submit", function (event) {
  event.preventDefault();
  sendPost();
});

document.getElementById("attach-post-image-btn").addEventListener("click", function () {
  document.getElementById("attach-post-image-input").click();
});

const feedContainer = document.getElementById("feed-container");

function setupSendPostButton(userProfileImage, userName, userCompany) {
  document.getElementById("send-post-btn").addEventListener("click", function (event) {
    event.preventDefault();
    submitPost(event, userProfileImage, userName, userCompany);

    const badgeSelect = document.getElementById("badge-select");
    const postInput = document.getElementById("post-input");
    const attachPostImageInput = document.getElementById("attach-post-image-input");

    const postData = {
      badge: badgeSelect.value,
      content: postInput.value,
      profileImage: userProfileImage,
      name: userName,
      company: userCompany,
      timestamp: new Date(),
    };

    if (attachPostImageInput.files[0]) {
      const reader = new FileReader();
      reader.onload = function (e) {
        postData.imageSrc = e.target.result;
        const postElement = createPost(postData);
        feedContainer.prepend(postElement);
        postInput.value = '';
        attachPostImageInput.value = '';
      };
      reader.readAsDataURL(attachPostImageInput.files[0]);
    } else {
      const postElement = createPost(postData);
      feedContainer.prepend(postElement);
      postInput.value = '';
    }

    // Save the post to local storage
    let savedPosts = JSON.parse(localStorage.getItem('savedPosts')) || [];
    savedPosts.unshift(postData);
    localStorage.setItem('savedPosts', JSON.stringify(savedPosts));
  });
}

function loadSavedPosts() {
  const savedPosts = JSON.parse(localStorage.getItem('savedPosts')) || [];
  savedPosts.forEach((postData) => {
    const postElement = createPost(postData);
    feedContainer.prepend(postElement);
  });
}

// Fetch user information from the server
fetch('/api/user-info')
  .then(response => response.json())
  .then(userInfo => {
    // Call the function with the fetched user information
    setupSendPostButton(userInfo.profileImage, userInfo.name, userInfo.company);
    loadSavedPosts(); // Load saved posts after the user information is fetched
  })
  .catch(error => {
    console.error('Error fetching user information:', error);
  })
  .finally(() => {
    setupSendPostButton(); // Call the function if the fetch request fails
  });




// Load saved posts from local storage
document.addEventListener('DOMContentLoaded', () => {
  const savedPosts = JSON.parse(localStorage.getItem('savedPosts')) || [];
  savedPosts.forEach((postData) => {
    const postElement = createPost(postData);
    feedContainer.prepend(postElement);
  });
});