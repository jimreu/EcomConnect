chrome.runtime.onInstalled.addListener(function () {
  const defaultUserData = {
    name: "",
    company: "",
    profilePhoto: chrome.runtime.getURL("defaultprofileicon.png"),
  };

  const defaultMessages = [];

  chrome.storage.sync.set({ userData: defaultUserData, messages: defaultMessages }, function () {
    console.log("User data and messages initialized.");
  });
});
